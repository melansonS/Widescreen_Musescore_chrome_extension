if(window.location.host === "musescore.com"){
  const header = document.getElementsByClassName("_2Dxmq")[0];
  const aside = document.getElementsByClassName("_1C7Q7")[0];
  const main = document.getElementsByClassName("_39vC0 _18aC2")[0];
  header.style['display'] = 'none';
  aside.style['display'] = 'none';
  main.style['width'] = '100%';
};